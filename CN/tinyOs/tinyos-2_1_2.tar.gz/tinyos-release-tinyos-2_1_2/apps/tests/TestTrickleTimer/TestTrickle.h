#ifndef TEST_TRICKLE_H
#define TEST_TRICKLE_H

#define UQ_TEST_TRICKLE "TestTrickle.TrickleTimer"

#endif
