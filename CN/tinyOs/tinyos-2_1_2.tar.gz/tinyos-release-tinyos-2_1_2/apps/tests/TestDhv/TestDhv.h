#ifndef __TESTDHV_H__
#define __TESTDHV_H__

/*enum {
  AM_DHV_TEST_MSG = 0xAB
};*/

#endif
