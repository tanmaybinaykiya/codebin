$Id: README.txt,v 1.4 2006-12-12 18:22:50 vlahan Exp $

README for Null
Author/Contact: tinyos-help@millennium.berkeley.edu

Description:

TestScheduler is a simple test application for a Scheduler's implementation
of the TaskBasic interface. The application has three tasks, each of
which toggles a different LED after a brief spin loop.

This application has little (if any) use to a TinyOS user; it is intended
to be a basic sanity test for schedulers.

Tools:

None.

Known bugs/limitations:

None


