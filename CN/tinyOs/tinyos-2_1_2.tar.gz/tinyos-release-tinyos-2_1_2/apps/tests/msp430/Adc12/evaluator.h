#ifndef EVALUATOR_H
#define EVALUATOR_H

#define EVALUATOR_CLIENT "ADC12.Evalutator.ID"

#endif
