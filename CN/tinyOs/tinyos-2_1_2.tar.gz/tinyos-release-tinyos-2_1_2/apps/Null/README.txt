$Id: README.txt,v 1.4 2006-12-12 18:22:48 vlahan Exp $

README for Null
Author/Contact: tinyos-help@millennium.berkeley.edu
@author Cory Sharp <cssharp@eecs.berkeley.edu>

Description:

Null is an empty skeleton application.  It is useful to test that the
build environment is functional in its most minimal sense, i.e., you
can correctly compile an application. It is also useful to test the
minimum power consumption of a node when it has absolutely no 
interrupts or resources active.

Tools:

None.

Known bugs/limitations:

Hahaha. Seriously.

