Subject: Re: [Tinyos] emacs mode for nesC
From: Vlado Handziski <handzisk@tkn.tu-berlin.de>
Date: Sat, 14 Feb 2004 10:29:43 +0100
To: tinyos@Millennium.Berkeley.EDU

Here is one for KDE (kate, kwrite, kdevelop).

Installation:

Just copy the file into $KDEDIR/share/apps/katepart/syntax

Vlado

On Thursday 12 February 2004 22:29, Cory Sharp wrote:

