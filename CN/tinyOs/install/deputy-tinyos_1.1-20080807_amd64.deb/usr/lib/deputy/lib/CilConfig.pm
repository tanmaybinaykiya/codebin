
$::archos    = "x86_LINUX";
$::cc        = "gcc";
$::cilhome   = "/home/klueska/tinyos-toolchain-packages/sources/deputy-tinyos-1.1/deputy-tinyos-1.1/cil";
$::default_mode = "GNUCC";

